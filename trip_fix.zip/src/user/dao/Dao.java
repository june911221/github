package user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import user.bean.Dto;

public class Dao {
	Connection conn=null;
	Statement stmt=null;
	
	public void Dao() {//db�� �Ѷ�� �޼ҵ�
		try{
			Class.forName("com.mysql.jdbc.Driver");
	}catch(Exception e){
		}
	}
	
	
	public void conn() {//db�� �����Ű��� �޼ҵ�
		try{
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/hjy","root","911221");
		}catch(Exception e){
			
		}
	}

	public void close() {
		try{
			
			stmt.close();
			
		}catch(Exception e) {
			
		}try{
			
			conn.close();
			
		}catch(Exception e) {
			
		}		
	}
	public ArrayList<Dto> list(){
		ArrayList<Dto> borderlist= new ArrayList<Dto>();
		try {
			conn();
			stmt=conn.createStatement();
			String command = "select * from border;";
			ResultSet rs=stmt.executeQuery(command);
			while(rs.next()) {
				Dto dto=new Dto();
				dto.setNumber(rs.getInt("number"));
				dto.setCategory(rs.getString("category"));
				dto.setTitle(rs.getString("title"));
				dto.setWritter(rs.getString("writter"));
				dto.setDate(rs.getTimestamp("date"));
				dto.setHits(rs.getInt("hits"));
				
				borderlist.add(dto);
			}
			}catch (Exception igException) {
				
			}
			return borderlist;
		}
	}